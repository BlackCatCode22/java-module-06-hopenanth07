package com.hope.zoo;


public class Hyena extends Animal {

    // Static field to track number of Hyenas created
    private static int numOfHyenas = 0;

    // Default constructor
    public Hyena() {
        super();
        numOfHyenas++;
    }

    // Full constructor using LocalDate for date fields
    public Hyena(String aniSex, String species, String aniBirthDate, String aniWeight, int age, String aniName,
                 String aniID, String aniColor, String aniLocation, String aniState, String aniArrivalDate) {
        super(aniSex, species, aniBirthDate, aniWeight, age, aniName, aniID, aniColor, aniLocation, aniState, aniArrivalDate);
        numOfHyenas++;
    }

    // Static getter for number of Hyenas
    public static int getNumOfHyenas() {
        return numOfHyenas;
    }
}

