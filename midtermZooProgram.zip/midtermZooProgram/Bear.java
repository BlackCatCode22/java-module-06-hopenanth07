package com.hope.zoo;

public class Bear extends Animal {

    // Static field to track number of Hyenas created
    private static int numOfBears = 0;

    // Default constructor
    public Bear() {
        super();
        numOfBears++;
    }

    // Full constructor using LocalDate for date fields
    public Bear(String aniSex, String species, String aniBirthDate, String aniWeight, int age, String aniName,
                 String aniID, String aniColor, String aniLocation, String aniState, String aniArrivalDate) {
        super(aniSex, species, aniBirthDate, aniWeight, age, aniName, aniID, aniColor, aniLocation, aniState, aniArrivalDate);
        numOfBears++;
    }

    // Static getter for number of Hyenas
    public static int getNumOfBears() {
        return numOfBears;
    }
}
