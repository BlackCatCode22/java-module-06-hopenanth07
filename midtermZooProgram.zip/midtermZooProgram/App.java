// Midterm Submission
// Hope Nanthavongdouangsy

package com.hope.zoo;
import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {

        // Hashmap for each key is a string and each value is an Animal
        // all animals are stored after the file
        HashMap<String, Animal> AnimalMap = new HashMap<>();

        // the text file that contains the animals
        String filePath = "arrivingAnimals.txt";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {

            // Reads each line until the end of the file (null)
            String line;

            while ((line = reader.readLine()) != null) {
                // splits line by the comma and space
                String[] ElementsofInput = line.split(",");

                // for each loop to split the lines
                int lineNum = 0;
                for (String thepart : ElementsofInput) {
                    System.out.println("element:" + lineNum + " " + thepart);
                    lineNum++;
                }

                // create variables to store our data
                String sex;
                String species;
                String birthSeason = "";
                String arrivalDates = Utilities.arrivalDate(); //helper method to return the date
                String weight;
                weight = ElementsofInput[3];
                String color;
                color = ElementsofInput[2];
                String location;
                location = ElementsofInput[4];
                String state;
                state = ElementsofInput[5];
                String name = "";
                String id = "";

                // split element 0
                String[] SplitElement0 = ElementsofInput[0].split(" ");
                int age = Integer.parseInt(SplitElement0[0]);
                sex = SplitElement0[3];
                species = SplitElement0[4];


                // split element 1
                String[] SplitElement1 = ElementsofInput[1].split(" ");
                birthSeason = SplitElement1[2];


                if (species.equals("hyena")) {
                    // generates the Hyena ID as Hy01 and the next animal ID added by 1
                    int countofAnimals = Hyena.getNumOfHyenas() + 1;
                    // prints a integer with two digits where it will be stored into the id
                    id = String.format("Hy%02d", countofAnimals);
                    // adds these information into the Animalmap with their ID
                    Hyena hyena = new Hyena(sex, species, birthSeason, weight, age, name, id, color, location, state, arrivalDates);
                    AnimalMap.put(id, hyena);
                }
                if (species.equals("lion")) {
                    int countofAnimals = Lion.getNumOfLions() + 1;
                    id = String.format("Li%02d", countofAnimals);
                    Lion lion = new Lion(sex, species, birthSeason, weight, age, name, id, color, location, state, arrivalDates);
                    AnimalMap.put(id, lion);
                    System.out.println(lion);
                }
                if (species.equals("tiger")) {
                    int countofAnimals = Tiger.getNumOfTigers() + 1;
                    id = String.format("Ti%02d", countofAnimals);
                    Tiger tiger = new Tiger(sex, species, birthSeason, weight, age, name, id, color, location, state, arrivalDates);
                    AnimalMap.put(id, tiger);
                    System.out.println(tiger);
                }
                if (species.equals("bear")) {
                    int countofAnimals = Bear.getNumOfBears() + 1;
                    id = String.format("Be%02d", countofAnimals);
                    Bear bear = new Bear(sex, species, birthSeason, weight, age, name, id, color, location, state, arrivalDates);
                    AnimalMap.put(id, bear);
                    System.out.println(bear);
                }


            }

        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        // opens a report txt file for the information to displayed
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            // the string order will tell us what species will be printed first to last
            String[] order = {"hyena", "lion", "tiger", "bear"};

            for (String sp : order) {
                // header ONCE per species
                writer.write(sp + "s:\n");
                writer.write("--------------------------------------\n");

                // lists the entire HashMap of animals
                for (Map.Entry<String, Animal> entry : AnimalMap.entrySet()) {
                    Animal animal = entry.getValue();
                    // checks if the animals belong to the right species
                    if (animal.getSpecies().equalsIgnoreCase(sp)) {
                        writer.write(
                                "ID: " + animal.getAniID() + "\n" +
                                        "Species: " + animal.getSpecies() + "\n" +
                                        "Sex: " + animal.getAniSex() + "\n" +
                                        "Age: " + animal.getAge() + "\n" +
                                        "Birth Season: " + animal.getAniBirthDate() + "\n" +
                                        "Weight: " + animal.getAniWeight() + "\n" +
                                        "Color: " + animal.getAniColor() + "\n" +
                                        "Location: " + animal.getAniLocation() + "\n" +
                                        "State: " + animal.getAniState() + "\n" +
                                        "Arrival Date: " + animal.getAniArrivalDate() + "\n" +
                                        "--------------------------------------\n"
                        );
                    }
                }
                writer.write("\n"); // blank line between species
            }

            // The total numbers of animals after the loop
            writer.write(
                    "The Number of Animals: " + Animal.getNumOfAnimals() +
                            ", Hyenas: " + Hyena.getNumOfHyenas() +
                            ", Lions: " + Lion.getNumOfLions() +
                            ", Tigers: " + Tiger.getNumOfTigers() +
                            ", Bears: " + Bear.getNumOfBears() + "\n"
            );

        } catch (IOException e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }
}