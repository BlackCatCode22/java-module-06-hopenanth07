package com.hope.zoo;

import java.time.LocalDate;

public class Tiger extends Animal {

    // Static field to track number of Tigers created
    private static int numOfTigers = 0;

    // Default constructor
    public Tiger() {
        super();
        numOfTigers++;
    }

    // Full constructor using LocalDate for date fields
    public Tiger(String aniSex, String species, String aniBirthDate, String aniWeight, int age, String aniName,
                 String aniID, String aniColor, String aniLocation, String aniState, String aniArrivalDate) {
        super(aniSex, species, aniBirthDate, aniWeight, age, aniName, aniID, aniColor, aniLocation, aniState, aniArrivalDate);
        numOfTigers++;
    }

    // Static getter for number of Hyenas
    public static int getNumOfTigers() {
        return numOfTigers;
    }
}


