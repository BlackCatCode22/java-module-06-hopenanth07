package com.hope.zoo;

import java.time.LocalDate;

public class Animal {

    // Static field to track number of animals
    private static int numOfAnimals = 0;

    // Attributes
    private String aniSex;
    private String species;
    private String aniBirthDate;
    private String aniWeight;
    private int age;
    private String aniName;
    private String aniID;
    private String aniColor;
    private String aniLocation;
    private String aniState;
    private String aniArrivalDate;

    // Default constructor
    public Animal() {
        // increment the num of animals when a new animal is created
        numOfAnimals++;
    }

    // Full animal constructor
    public Animal(String aniSex, String species, String aniBirthDate, String aniWeight, int age, String aniName,
                  String aniID, String aniColor, String aniLocation, String aniState, String aniArrivalDate) {
        numOfAnimals++;
        this.aniSex = aniSex;
        this.species = species;
        this.aniBirthDate = aniBirthDate;
        this.aniWeight = aniWeight;
        this.age = age;
        this.aniName = aniName;
        this.aniID = aniID;
        this.aniColor = aniColor;
        this.aniLocation = aniLocation;
        this.aniState = aniState;
        this.aniArrivalDate = aniArrivalDate;
    }

    // Getters and Setters

    public String getAniSex() {
        return aniSex;
    }

    public void setAniSex(String aniSex) {this.aniSex = aniSex;}
    public String getSpecies() { return  species; }
    public void setSpecies(String species) {this.species = species; }

    public String getAniBirthDate() {
        return aniBirthDate;
    }
    public void setAniBirthDate(String aniBirthDate) {
        this.aniBirthDate = aniBirthDate;
    }

    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }

    public String getAniWeight() {
        return aniWeight;
    }
    public void setAniWeight(String aniWeight) {
        this.aniWeight = aniWeight;
    }

    public String getAniName() {
        return aniName;
    }
    public void setAniName(String aniName) {
        this.aniName = aniName;
    }

    public String getAniID() {
        return aniID;
    }
    public void setAniID(String aniID) {
        this.aniID = aniID;
    }

    public String getAniColor() {
        return aniColor;
    }
    public void setAniColor(String aniColor) {
        this.aniColor = aniColor;
    }

    public String getAniLocation() {
        return aniLocation;
    }
    public void setAniLocation(String aniLocation) {this.aniLocation = aniLocation;}

    public String getAniState() {
        return aniState;
    }
    public void setAniState(String aniState) {this.aniState = aniState;}

    public String getAniArrivalDate() {
        return aniArrivalDate;
    }
    public void setAniArrivalDate(String aniArrivalDate) {
        this.aniArrivalDate = aniArrivalDate;
    }

    // Static getter for number of animals
    public static int getNumOfAnimals() {
        return numOfAnimals;
    }
}

