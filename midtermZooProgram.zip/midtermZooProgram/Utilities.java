package com.hope.zoo;

import java.util.Date;
import java.text.SimpleDateFormat;

public class Utilities {
    public static String arrivalDate (){
        Date Today = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formatterYear = new SimpleDateFormat("dd/MM/yyyy");
        String TodayDate = formatter.format(Today);
        String Todayyear = formatterYear.format(Today);
        return TodayDate;

    }
}
