package com.hope.zoo;


public class Lion extends Animal {

    // Static field to track number of Lions created
    private static int numOfLions = 0;

    // Default constructor
    public Lion() {
        super();
        numOfLions++;
    }

    // Full constructor using LocalDate for date fields
    public Lion(String aniSex, String species, String aniBirthDate, String aniWeight, int age, String aniName,
                 String aniID, String aniColor, String aniLocation, String aniState, String aniArrivalDate) {
        super(aniSex, species, aniBirthDate, aniWeight, age, aniName, aniID, aniColor, aniLocation, aniState, aniArrivalDate);
        numOfLions++;
    }

    // Static getter for number of Lions
    public static int getNumOfLions() {
        return numOfLions;
    }
}

